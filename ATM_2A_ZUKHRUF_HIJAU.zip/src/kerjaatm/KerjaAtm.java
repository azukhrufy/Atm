/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kerjaatm;

/**
 *
 * @author Acer
 */
public class KerjaAtm {

    /**
     * @param args the command line arguments
     */
       // main method creates and runs the ATM
   public static void main(String[] args) {
      ATM theATM = new ATM(); 
      
          theATM.run();
      
   }
} 
    

